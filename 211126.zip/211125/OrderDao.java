package com.spring.mvc2.dataTransfer.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class OrderDao {

	@Autowired
	private SqlSession sqlSession;
	
	/*
	 * 
	 * # Mapper To Dao
	 * 
	 *  - [ mybatis 연결 설정 ] 
	 *     1) [ pom.xml ] 의존성 추가
	 *     2) [ root-context.xml ] db 연결 정보 설정
	 *     3) [ mybatis-config.xml ] mybatis설정 정보 
 	 *     4) [ *.xml ] mapper 파일 생성
 	 *     5) SqlSession 객체를 생성하여 쿼리문을 실행한다.
 	 *     
	 *  - 한개의 데이터를 조회할 경우      .selectOne() 메서드를 사용한다.
	 *  - 한개 이상의 데이터를 조회할 경우 .selectList() 메서드를 사용하며 반환데이터는 List로 처리할 수 있다.
	 *      주의) mapper파일에서의 resultType이 List가 아니고 . selectList() 메서드로 List를 처리한다.
	 *  
	 *  - insert쿼리를 사용할 경우 .insert() 메서드를 사용한다.
	 *  - update쿼리를 사용할 경우 .update() 메서드를 사용한다.
	 *  - delete쿼리를 사용할 경우 .delete() 메서드를 사용한다.
	 * */
	
	// 1) Mapper > Dao 전송 예시
	// 2) Mapper > Dao 전송 예시
	// 3) Mapper > Dao 전송 예시
	
}
